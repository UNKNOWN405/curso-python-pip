import charts

def run():
    charts.generate_pie_chart()

if __name__ == '__main__':
    run()